import logo from './logo.svg';
import './App.css';
import Title from './components/title';
import Mysidebar from './components/sidebar'
import Main from './components/main'


function App() {
  return (
    <div className="App">
      <Title/>
        <div className="SidebarClass">
        <Mysidebar/>
          </div>
        <Main/>
        <img src={logo} className="App-logo" alt="logo" />
    </div>
  );
}

export default App;
