import React from 'react';

function Title() {
    return(
        <nav class="bg-dark navbar-dark navbar">
            <div className="NTUT">
                <h3>Welcome to NTUT Web Programming</h3>
            </div>
        </nav>
    )
}

export default Title;
