import React from 'react';
import ReactDOM from 'react-dom/client';
import { Sidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';

function Mysidebar(){
  return (
    <Sidebar>
      <Menu>
        <SubMenu label="Charts">
          <MenuItem> Pie charts </MenuItem>
          <MenuItem> Line charts </MenuItem>
        </SubMenu>
        <MenuItem> Documentation </MenuItem>
        <MenuItem> Calendar </MenuItem>
        <MenuItem> Calculator </MenuItem>
        <MenuItem> Schedule </MenuItem>
        <MenuItem> Work flow </MenuItem>
      </Menu>
      </Sidebar>
  );
}
export default Mysidebar;
