import React from 'react';

function Main(){
  return(
    <div className="Mainclass">
        <h1>Hope you enjoy!</h1>
        <h3>109990022 Yungmin Kim</h3>
    </div>
  );
}
export default Main;
